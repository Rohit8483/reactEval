import {Form} from "./components/Form";
// import {Datas} from "./components/Datas";


function App() {
  return <div>
    <Form/>
  
  </div>;
}

export default App;

